# TFL — Franchise (Web)

Open web/index.html to play. Use GitHub Pages via .github/workflows/pages.yml.
